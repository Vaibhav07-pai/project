import React from 'react'

export default function Functionalcomponent() {
  return (
    <div>Functionalcomponent</div>
  )
}

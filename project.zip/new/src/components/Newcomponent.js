import React from 'react'

function Newcomponent(props) {
  return (
    <div>
        <h1>{props.name}hello gudmrng</h1>
    </div>
  )
}

export default Newcomponent
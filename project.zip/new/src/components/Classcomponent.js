import React, { Component } from 'react'

export default class Classcomponent extends Component {
    constructor(){
        super();
        this.state = {
        msg: 'achaa to hum chalte hai'
        };
    }
  render() {
    return (
      <div>
        <h1>{this.state.msg} </h1>
      </div>
    )
  }
}

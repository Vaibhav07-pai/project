import React, { Component } from 'react'

export default class Count extends Component {
    constructor(){
        super()
        this.state={
            count:0
        }

    }
    incrementCount = () =>{
        this.setState({count:this.state.count+1})
    }
    decrementCount = () =>{
      this.setState({count:this.state.count-1})
  }
  multipleCount = () =>{
    this.setState({count:this.state.count*2})
}

  render() {
    return (
      <div>
         <button onMouseMove={this.incrementCount}> Increment </button>
        <h1>
           {this.state.count}
        </h1>
        <button onMouseMove={this.decrementCount}>decrement</button>
        <h2>{this.state.count}</h2>
        <button onMouseMove={this.multipleCount}>multiple</button>
        <h3>{this.state.count}</h3>

      </div>
    
    )
  }
}
